from django.contrib import admin
from .models import Livro

admin.site.register(Livro)
